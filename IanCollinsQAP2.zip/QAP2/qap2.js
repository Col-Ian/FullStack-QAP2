const http = require("http");
const fs = require("fs");
const { isAbsolute } = require("path");
const EventEmitter = require("events");

// create the object to actually use
const emitter = new EventEmitter();

let defaultPath = "";

// This will run every time somebody accesses a site, and will display which
emitter.on("Event ran", function () {
  console.log(`Path to ${defaultPath} used`);
});

const server = http.createServer((req, res) => {
  console.log(req.url, req.method);

  res.setHeader("Content-Type", "text/html");

  let path = "./views/";
  switch (req.url) {
    case "/":
      path += "index.html";
      res.statusCode = 200;
      defaultPath = path;
      emitter.emit("Event ran");
      break;
    case "/contact":
      path += "contact.html";
      res.statusCode = 200;
      defaultPath = path;
      emitter.emit("Event ran");
      break;
    case "/products":
      path += "products.html";
      res.statusCode = 200;
      defaultPath = path;
      emitter.emit("Event ran");
      break;
    case "/subscribe":
      path += "subscribe.html";
      res.statusCode = 200;
      defaultPath = path;
      emitter.emit("Event ran");
      break;
    case "/about":
      path += "about.html";
      res.statusCode = 200;
      defaultPath = path;
      emitter.emit("Event ran");
      break;
    case "/about-me":
      res.statusCode = 301;
      res.setHeader("Location", "/about");
      res.end();
      console.log(`Re-routed to /about.`);
      defaultPath = path;
      emitter.emit("Event ran");
      break;
    default:
      path += "404.html";
      res.statusCode = 404;
      defaultPath = path;
      emitter.emit("Event ran");
      break;
  }

  fs.readFile(path, (err, data) => {
    if (err) {
      console.log(err);
      res.end();
    } else {
      res.write(data);
      res.end();
    }
  });
});

server.listen(3000, "localhost", () => {
  console.log("listening for requests on port 3000");
});
